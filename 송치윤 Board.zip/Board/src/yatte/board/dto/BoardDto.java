package yatte.board.dto;

import java.util.Date;

public class BoardDto {

	private String id;
	private int postnum;
	private int category;
	private int group_num;
	private int group_order;
	private String title;
	private String content;
	private Date today;
	
	public BoardDto() {
		
	}
	
	public BoardDto(String id, int postnum, int category, int group_num, int group_order, String title, String content,
			Date today) {
		this.id = id;
		this.postnum = postnum;
		this.category = category;
		this.group_num = group_num;
		this.group_order = group_order;
		this.title = title;
		this.content = content;
		this.today = today;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getPostnum() {
		return postnum;
	}

	public void setPostnum(int postnum) {
		this.postnum = postnum;
	}

	public int getCategory() {
		return category;
	}

	public void setCategory(int category) {
		this.category = category;
	}

	public int getGroup_num() {
		return group_num;
	}

	public void setGroup_num(int group_num) {
		this.group_num = group_num;
	}

	public int getGroup_oder() {
		return group_order;
	}

	public void setGroup_oder(int group_oder) {
		this.group_order = group_oder;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getToday() {
		return today;
	}

	public void setToday(Date today) {
		this.today = today;
	}
	
	
	
	 
}
