package yatte.board.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import yatte.board.db.SqlMapConfig;
import yatte.board.dto.BoardDto;

public class BoardDao extends SqlMapConfig{

	private String namespace = "board.mapper.";
	
	public List<BoardDto> selectList(){
		SqlSession session = null;
		
		session = getSqlSessionFactory().openSession();
		
		List<BoardDto> list = session.selectList(namespace+"selectlist");
		return list;
	}
	
	public BoardDto selectone(int postnum) {

		BoardDto dto = new BoardDto();
		
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("postnum",postnum);
		
		SqlSession session = null;
		
		session = getSqlSessionFactory().openSession();
		dto = session.selectOne(namespace+"selectOne", map);
		
		return dto;
		
	}
	
	public int insert(BoardDto dto) {
		
		SqlSession session = null;
		
		int res = 0;
		try {
			session = getSqlSessionFactory().openSession();
			res = session.insert(namespace+"insert", dto);
			if(res>0) {
				session.commit();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return res;
	}
	
	public int delete(BoardDto dto) {
		
		SqlSession session = null;
		
		int res = 0;
		
		try {
			session = getSqlSessionFactory().openSession();
			res = session.delete(namespace+"delete", dto);
			if(res>0) {
				session.commit();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return res;
	}
	
	public int update(BoardDto dto) {
		
		SqlSession session = null;
		
		int res = 0;
		
		try {
			session = getSqlSessionFactory().openSession();
			res = session.update(namespace+"update",dto);
			if(res>0) {
				session.commit(); 	
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return res;
		
	}
	public int answer(BoardDto dto) {
		SqlSession session = null;
		
		int res = 0;
		
		try {
			session = getSqlSessionFactory().openSession();
			res = session.update(namespace+"answer",dto);
			if(res>0) {
				session.commit(); 	
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return res;
	}
}
